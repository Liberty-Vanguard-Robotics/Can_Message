"""
"""

__all__ = [
    "SerialBus",
    "serial_can",
]

from can.interfaces.serial.serial_can import SerialBus
